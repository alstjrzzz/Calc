import java.util.*;

public class Infix2Postfix {
	public static String convert(String exp) {
		if(exp == null || exp.length() == 0) return null;
		
		StringTokenizer st = new StringTokenizer(exp, "+-X/()", true);
		Stack<String> stack = new Stack<String>();
		StringBuffer buf = new StringBuffer();
		
		while(st.hasMoreTokens()) {
			String tok = st.nextToken();
			switch (tok){
	            case "+":
	            case "-":
	            case "X":
	            case "/":
	                while (!stack.empty() && getPriority(stack.peek().charAt(0)) >= getPriority(tok.charAt(0))) {
	                    buf.append(stack.pop().trim());
	                    buf.append(" ");
	                }
	                stack.push(tok);
	                break;
	            case "(":
	                stack.push(tok);
	                break;
	            case ")":
	                while(!stack.empty() && !stack.peek().equals("(")){
	                    buf.append(stack.pop().trim());
	                    buf.append(" ");
	                }
	                stack.pop();
	                break;
	            default:
	                buf.append(tok.trim());
	                buf.append(" ");
			}
		}
		
		
		while(!stack.empty()) {
			buf.append(stack.pop());
			buf.append(" ");
		}
		return buf.toString();
	}
	
	
	private static int getPriority(char op) {
		switch (op) {
			case '(':
			case ')':
				return 0;
			case '+':
			case '-':
				return 1;
			case 'X':
			case '/':
				return 2;
			default:
				return -1;
		}
	}
}