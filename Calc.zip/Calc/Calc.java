import java.util.*;

public class Calc {
    public static double eval(String exp) {
        StringTokenizer st = new StringTokenizer(exp);
        Stack<Double> stack = new Stack<Double>();

        while (st.hasMoreTokens()) {
            String tok = st.nextToken();
            if (isOperator(tok)) {
                double v1 = stack.pop();
                double v2 = stack.pop();
                double value = 0;

                switch (tok) {
                    case "+":
                        value = v2 + v1;
                        break;
                    case "-":
                        value = v2 - v1;
                        break;
                    case "X":
                        value = v2 * v1;
                        break;
                    case "/":
                        value = v2 / v1;
                        break;
                }
                stack.push(value);
            } else {
                stack.push(Double.parseDouble(tok));
            }
        }
        double result = stack.pop();
        return result;
    }

    private static boolean isOperator(String token) {
        return token.equals("+") || token.equals("-") || token.equals("X") || token.equals("/");
    }
}
